SalsaSegura Logo Package

Included:
- Transparent PNG master
- PNG sizes: 1024, 512, 256, 128, 64, 32 px
- Black-background PNG
- White and black monochrome transparent PNGs
- App icons: 1024, 512, 180 px
- Print PDF

Important:
The source artwork was AI-generated raster artwork. These files are cleaned raster derivatives.
A true SVG/EPS vector requires manually redrawing/tracing the emblem's curves; simply wrapping
the PNG inside an SVG would not create a real vector logo.
